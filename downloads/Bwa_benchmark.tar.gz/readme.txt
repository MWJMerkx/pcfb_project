Requirements:
Have bwa installed:
	sudo apt-get install bwa
Make sure you have execute permissions for run_benchmark.sh:
	chmod u+x ./run_benchmark.sh

Instructions
	Run run_benchmark.sh either via terminal or by clicking on it.
	Results will be in results folder. 

Upload
	Currently we have not set up a consitent place for uploading data.
	If you want to help us gather benchmark data please visit our github.
	Open an issue saying you got a benchmark for us and upload the files in that 		issue.
	

