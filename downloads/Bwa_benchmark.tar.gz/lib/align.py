#! /usr/bin/env python3

#Michiel Merx and Inne Lemstra 2017-01-24
import subprocess
import time

def benchmark(outputPreStep, shortReads):
	output = "./result/Bwa_alignment_paired.sam"
	
	startTime = time.time()
	debug = go(outputPreStep, shortReads, output)
	endTime = time.time()
	
	bmAlign = endTime - startTime
	return([bmAlign, debug])

def go(indexOutputPath, shortReadspath, alignOutputPath):
	comAlign = "bwa mem -P {0} {1} > {3}"\
		.format(indexOutputPath, shortReadspath,\
			 shortReadspath[1], alignOutputPath)
	debug = subprocess.call(comAlign, shell = True)
	return(debug)

if __name__ == "main":
	indexOutputPath = "./index_files/bwa_index"
	shortReadpath =  "./sample/E_coli_MG1655.fasta"
	alginOutputPath =  "./result/Bwa_alignment_paired_from_main.sam"
	debug = go(indexOutputPath, shortReadpath, alginOutputPath)
