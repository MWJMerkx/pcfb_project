#!/bin/bash

python3 ./lib/pipeline.py


